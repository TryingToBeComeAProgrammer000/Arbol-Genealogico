# interfaz/tab_familias_integrantes.py
import tkinter as tk
from tkinter import ttk, messagebox

class TabFamiliasIntegrantes:
    def __init__(self, parent, gestor_familias):
        self.parent = parent
        self.gestor = gestor_familias
        self.frame = ttk.Frame(parent)
        
        # Datos para los menús desplegables
        self.generos = ["Masculino", "Femenino", "No especificado"]
        self.provincias = [
            "San José", "Alajuela", "Cartago", "Heredia", "Guanacaste", 
            "Puntarenas", "Limón", "No especificado"
        ]
        self.estados_civiles = [
            "Soltero", "Casado", "Divorciado", "Viudo", "Unión Libre", 
            "Separado", "No especificado"
        ]
        
        self.crear_widgets()

    def crear_widgets(self):
        main_frame = ttk.Frame(self.frame)
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Selección de familia
        select_frame = ttk.LabelFrame(main_frame, text="Seleccionar Familia")
        select_frame.pack(fill="x", pady=10, padx=10)

        ttk.Label(select_frame, text="Familia:").grid(row=0, column=0, padx=5, pady=10, sticky="w")
        self.familia_var = tk.StringVar()
        self.familia_combo = ttk.Combobox(select_frame, textvariable=self.familia_var, width=50, state="readonly")
        self.familia_combo.grid(row=0, column=1, padx=5, pady=10)
        self.familia_combo.bind('<<ComboboxSelected>>', self.cargar_miembros_familia)

        ttk.Button(select_frame, text="Actualizar Lista", 
                  command=self.actualizar_lista_familias).grid(row=0, column=2, padx=10, pady=10)

        # Formulario para nuevo miembro
        form_frame = ttk.LabelFrame(main_frame, text="Registrar Nuevo Miembro")
        form_frame.pack(fill="x", pady=10, padx=10)

        # Primera fila
        ttk.Label(form_frame, text="Cédula:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.cedula_entry = ttk.Entry(form_frame, width=15)
        self.cedula_entry.grid(row=0, column=1, padx=5, pady=5)

        ttk.Label(form_frame, text="Nombre:").grid(row=0, column=2, padx=5, pady=5, sticky="w")
        self.nombre_entry_miembro = ttk.Entry(form_frame, width=30)
        self.nombre_entry_miembro.grid(row=0, column=3, padx=5, pady=5)

        # Segunda fila
        ttk.Label(form_frame, text="Fecha Nacimiento (AAAA-MM-DD):").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.fecha_nac_entry = ttk.Entry(form_frame, width=15)
        self.fecha_nac_entry.grid(row=1, column=1, padx=5, pady=5)

        ttk.Label(form_frame, text="Fecha Fallecimiento (opcional):").grid(row=1, column=2, padx=5, pady=5, sticky="w")
        self.fecha_fall_entry = ttk.Entry(form_frame, width=15)
        self.fecha_fall_entry.grid(row=1, column=3, padx=5, pady=5)

        # Tercera fila - Menús desplegables
        ttk.Label(form_frame, text="Género:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.genero_var = tk.StringVar(value="No especificado")
        self.genero_combo = ttk.Combobox(form_frame, textvariable=self.genero_var, 
                                        values=self.generos, state="readonly", width=15)
        self.genero_combo.grid(row=2, column=1, padx=5, pady=5)

        ttk.Label(form_frame, text="Provincia:").grid(row=2, column=2, padx=5, pady=5, sticky="w")
        self.provincia_var = tk.StringVar(value="No especificado")
        self.provincia_combo = ttk.Combobox(form_frame, textvariable=self.provincia_var, 
                                           values=self.provincias, state="readonly", width=20)
        self.provincia_combo.grid(row=2, column=3, padx=5, pady=5)

        # Cuarta fila
        ttk.Label(form_frame, text="Estado Civil:").grid(row=3, column=0, padx=5, pady=5, sticky="w")
        self.estado_civil_var = tk.StringVar(value="No especificado")
        self.estado_civil_combo = ttk.Combobox(form_frame, textvariable=self.estado_civil_var, 
                                              values=self.estados_civiles, state="readonly", width=20)
        self.estado_civil_combo.grid(row=3, column=1, padx=5, pady=5)

        # Botón de registro
        ttk.Button(form_frame, text="Registrar Miembro", 
                  command=self.registrar_miembro).grid(row=3, column=3, padx=10, pady=10)

        # Área de miembros
        members_frame = ttk.LabelFrame(main_frame, text="Miembros de la Familia")
        members_frame.pack(fill="both", expand=True, pady=10, padx=10)

        # Treeview para mostrar miembros
        member_columns = ('Cédula', 'Nombre', 'Nacimiento', 'Fallecimiento', 'Género', 'Provincia', 'Estado Civil')
        self.members_tree = ttk.Treeview(members_frame, columns=member_columns, show='headings', height=10)
        
        # Definir encabezados
        for col in member_columns:
            self.members_tree.heading(col, text=col)
            self.members_tree.column(col, width=100)
        
        # Scrollbars
        vsb_members = ttk.Scrollbar(members_frame, orient="vertical", command=self.members_tree.yview)
        hsb_members = ttk.Scrollbar(members_frame, orient="horizontal", command=self.members_tree.xview)
        self.members_tree.configure(yscrollcommand=vsb_members.set, xscrollcommand=hsb_members.set)
        
        # Grid layout
        self.members_tree.grid(row=0, column=0, sticky='nsew')
        vsb_members.grid(row=0, column=1, sticky='ns')
        hsb_members.grid(row=1, column=0, sticky='ew')
        
        members_frame.grid_rowconfigure(0, weight=1)
        members_frame.grid_columnconfigure(0, weight=1)

        # Cargar lista de familias
        self.actualizar_lista_familias()

    def actualizar_lista_familias(self):
        """Actualiza la lista de familias en el combobox de integrantes"""
        try:
            familias = self.gestor.listar_familias()
            familia_options = [f"{f['id']} - {f['nombre']}" for f in familias]
            self.familia_combo['values'] = familia_options
            
            if familia_options:
                self.familia_combo.set(familia_options[0])
                self.cargar_miembros_familia()
                
        except Exception as e:
            messagebox.showerror("Error", f"Error al actualizar lista de familias: {e}")

    def registrar_miembro(self):
        # Validar selección de familia
        familia_seleccionada = self.familia_var.get()
        if not familia_seleccionada:
            messagebox.showwarning("Advertencia", "Seleccione una familia")
            return
        
        # Extraer ID de la familia
        try:
            familia_id = familia_seleccionada.split(" - ")[0]
        except:
            messagebox.showerror("Error", "Formato de familia inválido")
            return

        # Obtener datos del formulario
        cedula = self.cedula_entry.get().strip()
        nombre = self.nombre_entry_miembro.get().strip()
        fecha_nac = self.fecha_nac_entry.get().strip()
        fecha_fall = self.fecha_fall_entry.get().strip() or None
        genero = self.genero_var.get()
        provincia = self.provincia_var.get()
        estado_civil = self.estado_civil_var.get()

        # Validaciones básicas
        if not cedula or not nombre or not fecha_nac:
            messagebox.showwarning("Advertencia", "Cédula, nombre y fecha de nacimiento son obligatorios")
            return

        try:
            miembro = self.gestor.insertar_miembro(
                familia_id, cedula, nombre, fecha_nac, fecha_fall,
                genero, provincia, estado_civil
            )
            messagebox.showinfo("Éxito", "Miembro registrado correctamente")
            
            # Limpiar formulario
            self.limpiar_formulario_miembro()
            
            # Recargar lista de miembros
            self.cargar_miembros_familia()
            
        except ValueError as e:
            messagebox.showerror("Error", str(e))
        except Exception as e:
            messagebox.showerror("Error", f"Error al registrar miembro: {e}")

    def cargar_miembros_familia(self, event=None):
        """Carga los miembros de la familia seleccionada"""
        # Limpiar treeview de miembros
        for item in self.members_tree.get_children():
            self.members_tree.delete(item)
        
        familia_seleccionada = self.familia_var.get()
        if not familia_seleccionada:
            return
            
        try:
            familia_id = familia_seleccionada.split(" - ")[0]
            miembros = self.gestor.obtener_miembros(familia_id)
            
            for miembro in miembros:
                self.members_tree.insert('', tk.END, values=(
                    miembro.get('cedula', ''),
                    miembro.get('nombre', ''),
                    miembro.get('fecha_nacimiento', ''),
                    miembro.get('fecha_fallecimiento', '') or '',
                    miembro.get('genero', ''),
                    miembro.get('lugar_residencia', ''),
                    miembro.get('estado_civil', '')
                ))
                
        except Exception as e:
            messagebox.showerror("Error", f"Error al cargar miembros: {e}")

    def limpiar_formulario_miembro(self):
        """Limpia el formulario de registro de miembros"""
        self.cedula_entry.delete(0, tk.END)
        self.nombre_entry_miembro.delete(0, tk.END)
        self.fecha_nac_entry.delete(0, tk.END)
        self.fecha_fall_entry.delete(0, tk.END)
        self.genero_var.set("No especificado")
        self.provincia_var.set("No especificado")
        self.estado_civil_var.set("No especificado")